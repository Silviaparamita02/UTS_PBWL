<h2>Tambah Roti</h2>

<form action="barang_proses.php" method="post">
    <table>
        <tr>
            <td>Nama Roti</td>
            <td><input type="text" name="barang_nama"></td>
        </tr>
        <tr>
            <td>Harga Roti</td>
            <td><input type="text" name="barang_harga"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>