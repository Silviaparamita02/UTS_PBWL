<?php

namespace Inc;

class koneksi {

    public object $db;

    public function __construct() {
        $this->db = new \PDO("mysql:host=localhost;dbname=dbtokoo", "root", "");
    }
}

$conn = mysqli_connect("localhost","root","","dbtokoo") or die(mysqli_connect_error());

?>