<h2>Tambah Pelanggan</h2>

<form action="pelanggan_proses.php" method="post">
    <table>
        <tr>
            <td>Nama</td>
            <td><input type="text" name="pelanggan_nama"></td>
        </tr>
        <tr>
            <td>Nomor Hp</td>
            <td><input type="text" name="pelanggan_nomorhp"></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td><input type="text" name="pelanggan_alamat"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>